import torch
import torch.nn as nn
from lib.pvt import Hitnet
def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

def count_flops(model, input_size):
    flops = 0
    def conv_hook(module, input, output):
        nonlocal flops
        # Conv layer FLOPs: 2 * out_channels * (kernel_w * kernel_h * in_channels) * output_w * output_h
        batch_size, out_channels, output_h, output_w = output.shape
        kernel_w, kernel_h = module.kernel_size
        in_channels = module.in_channels
        flops += 2 * out_channels * (kernel_w * kernel_h * in_channels) * output_h * output_w

    def linear_hook(module, input, output):
        nonlocal flops
        # Linear layer FLOPs: 2 * input_features * output_features
        input_features = module.in_features
        output_features = module.out_features
        flops += 2 * input_features * output_features

    hooks = []
    for layer in model.modules():
        if isinstance(layer, nn.Conv2d):
            hooks.append(layer.register_forward_hook(conv_hook))
        elif isinstance(layer, nn.Linear):
            hooks.append(layer.register_forward_hook(linear_hook))

    # Generate a dummy input tensor
    dummy_input = torch.randn(1, *input_size)
    model(dummy_input)

    for hook in hooks:
        hook.remove()

    return flops

# Define your model

# Instantiate the model and define the input size
model = Hitnet()
input_size = (3, 352, 352)

# Calculate the number of parameters and FLOPs
num_params = count_parameters(model)
num_flops = count_flops(model, input_size)
num_gflops = num_flops / 1e9

print(f'Number of parameters: {num_params}')
print(f'Number of FLOPs: {num_flops}')
print(f'Number of GFLOPs: {num_gflops}')
