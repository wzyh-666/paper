import torch
from torch.autograd import Variable
import os
import argparse
from datetime import datetime
from lib.pvt import Hitnet
from utils.dataloader import get_loader, test_dataset
from utils.utils import clip_gradient, adjust_lr, AvgMeter
import torch.nn.functional as F
import numpy as np
import logging
from tensorboardX import SummaryWriter

import matplotlib.pyplot as plt
# import matplotlib.pyplot as plt
####
####CUDA_VISIBLE_DEVICES=0 python3 Train.py
####
#加载预训练权重
def load_matched_state_dict(model, state_dict, print_stats=True):
    """
    Only loads weights that matched in key and shape. Ignore other weights.
    """
    num_matched, num_total = 0, 0
    curr_state_dict = model.state_dict()
    for key in curr_state_dict.keys():
        num_total += 1
        if key in state_dict and curr_state_dict[key].shape == state_dict[key].shape:
            curr_state_dict[key] = state_dict[key]
            num_matched += 1
    model.load_state_dict(curr_state_dict)
    if print_stats:
        print(f'Loaded state_dict: {num_matched}/{num_total} matched')

#计算损失权重！
def structure_loss(pred, mask):
    weit = 1 + 5 * torch.abs(F.avg_pool2d(mask, kernel_size=31, stride=1, padding=15) - mask)   #增强边缘，因为池化之后边缘像素与池化之后的同位置像素插值较大。

    # weit_np = weit.squeeze().cpu().detach().numpy()
    #
    # # 使用 matplotlib 显示图像
    # plt.imshow(weit_np[0], cmap='gray')
    # plt.colorbar()
    # plt.title("Weit Image")
    # plt.show()

    wbce = F.binary_cross_entropy_with_logits(pred, mask, reduce='none')
    wbce = (weit * wbce).sum(dim=(2, 3)) / weit.sum(dim=(2, 3))          #加权增强边缘的bce损失

    pred = torch.sigmoid(pred)
    inter = ((pred * mask) * weit).sum(dim=(2, 3))
    union = ((pred + mask) * weit).sum(dim=(2, 3))
    wiou = 1 - (inter + 1) / (union - inter + 1)

    return (wbce + wiou).mean()        #最终结构损失


#评估在验证集上的性能，并在性能最优的时候保存参数。
def val(model, epoch, save_path, writer):
    """
    validation function
    """
    global best_mae, best_epoch
    model.eval()
    with torch.no_grad():
        mae_sum = 0
        # test_loader = test_dataset(image_root=opt.test_path + 'Imgs/',
        #                           gt_root=opt.test_path + 'GT/',
        #                           testsize=opt.trainsize)
        test_loader = test_dataset( image_root=opt.test_path + '/test-rgb/',
                                    dolp_root=opt.test_path+'/test-dop/',
                                    gt_root=opt.test_path + '/test-gt/',
                                    testsize=opt.trainsize)

        for i in range(test_loader.size):
            image,dolp,gt, name = test_loader.load_data()
            gt = np.asarray(gt, np.float32)
            gt /= (gt.max() + 1e-8)
            image = image.cuda()
            dolp = dolp.cuda()

            res, res1 = model(image,dolp)
            # eval Dice
            res = F.upsample(res[-1] + res1, size=gt.shape, mode='bilinear', align_corners=False)
            res = res.sigmoid().data.cpu().numpy().squeeze()
            res = (res - res.min()) / (res.max() - res.min() + 1e-8)
            mae_sum += np.sum(np.abs(res - gt)) * 1.0 / (gt.shape[0] * gt.shape[1])

        mae = mae_sum / test_loader.size
        writer.add_scalar('MAE', torch.tensor(mae), global_step=epoch)
        print('Epoch: {}, MAE: {}, bestMAE: {}, bestEpoch: {}.'.format(epoch, mae, best_mae, best_epoch))
        if epoch == 1:
            best_mae = mae
        else:
            if mae < best_mae:
                best_mae = mae
                best_epoch = epoch
                torch.save(model.state_dict(), save_path + 'Net_epoch_best.pth')      #只保存最好的参数
                print('Save state_dict successfully! Best epoch:{}.'.format(epoch))
                # epoc_logger.info(f'Epoch: {epoch}, MAE: {mae},bestEpoch: {best_epoch},bestMAE: {best_mae}')
        logging.info(
            '[Val Info]:Epoch:{} MAE:{} bestEpoch:{} bestMAE:{}'.format(epoch, mae, best_epoch, best_mae))
        epoc_logger.info(
            '[Val Info]:Epoch:{} MAE:{} bestEpoch:{} bestMAE:{}'.format(epoch, mae, best_epoch, best_mae))

def train(train_loader, model, optimizer, epoch, test_path):
    model.train()  # 将模型设置为训练模式，这将启用dropout和batch normalization。
    global best  # 声明一个全局变量，用于记录最佳模型性能。
    size_rates = [1]  # 尺寸倍率列表，通常用于多尺度训练，这里只使用单一尺度倍率1。
    loss_P2_record = AvgMeter()  # 初始化一个记录平均损失值的工具。

    for i, pack in enumerate(train_loader, start=1):  # 遍历训练数据加载器中的数据包。
        for rate in size_rates:  # 遍历尺寸倍率列表。
            optimizer.zero_grad()  # 清除优化器中的梯度。

            # 数据准备
            images,dolps, gts = pack  # 从数据包中解包图像和标签。
            images = Variable(images).cuda()  # 将图像移动到GPU。
            dolps = Variable(dolps).cuda()
            gts = Variable(gts).cuda()  # 将标签移动到GPU。      4 1 704 704

            # 重缩放
            trainsize = int(round(opt.trainsize * rate / 32) * 32)  # 计算新的训练尺寸（32的倍数）。
            if rate != 1:
                images = F.upsample(images, size=(trainsize, trainsize), mode='bilinear', align_corners=True)  # 重缩放图像。
                dolps = F.upsample(dolps, size=(trainsize, trainsize), mode='bilinear', align_corners=True)
                gts = F.upsample(gts, size=(trainsize, trainsize), mode='bilinear', align_corners=True)  # 重缩放标签。

            # 前向传播
            P1, P2 = model(images,dolps)  # 使用模型对图像进行预测，得到两个输出。

            # 损失函数
            losses = [structure_loss(out, gts) for out in P1]  # 计算P1的各层输出的结构损失。
            loss_p1 = 0
            gamma = 0.2  # 权重系数。
            for it in range(len(P1)):  # 累积各层输出的加权损失。
                loss_p1 += (gamma * it) * losses[it]

            loss_P2 = structure_loss(P2, gts)  # 计算P2的结构损失。
            loss = loss_p1 + loss_P2  # 总损失为P1和P2的损失之和。

            # 反向传播
            loss.backward()  # 计算损失的梯度。
            clip_gradient(optimizer, opt.clip)  # 梯度裁剪，防止梯度爆炸。
            optimizer.step()  # 更新模型参数。

            # 记录损失
            if rate == 1:
                loss_P2_record.update(loss_P2.data, opt.batchsize)  # 更新损失记录。

        # 训练可视化
        if i % opt.print_interval == 0 or i == total_step:  # 每50步或在最后一步时，打印损失信息并记录日志。
            print('{} Epoch [{:03d}/{:03d}], Step [{:04d}/{:04d}], '
                  ' lateral-5: {:0.4f}]'.
                  format(datetime.now(), epoch, opt.epoch, i, total_step,
                         loss_P2_record.show()))  # 打印当前时间、轮次、步骤和损失。
            logging.info('{} Epoch [{:03d}/{:03d}], Step [{:04d}/{:04d}], '
                         ' lateral-5: {:0.4f}]'.
                         format(datetime.now(), epoch, opt.epoch, i, total_step,
                                loss_P2_record.show()))  # 记录日志。
        # if i == total_step:
        #     epoc_logger.info('{} Epoch [{:03d}/{:03d}], Step [{:04d}/{:04d}], '
        #                  ' lateral-5: {:0.4f}]'.
        #                  format(datetime.now(), epoch, opt.epoch, i, total_step,
        #                         loss_P2_record.show()))
    # 保存模型
    save_path = opt.save_path
    if epoch % opt.epoch_save == 0:  # 每隔指定轮次保存一次模型。
        pth_save_path =os.path.join(save_path,'pth')
        torch.save(model.state_dict(), pth_save_path + 'Hitnet-PVT.pth')  # 保存模型参数。


if __name__ == '__main__':

    ##################model_name#############################
    # model_name = 'Hitnet_pvt_wo_pretrained_fusion'
    model_name = 'Hitnet'

    ###############################################
    parser = argparse.ArgumentParser()
    parser.add_argument('--epoch', type=int,default=300, help='epoch number')
    parser.add_argument('--lr', type=float,default=1e-5, help='learning rate')
    parser.add_argument('--optimizer', type=str,default='AdamW', help='choosing optimizer AdamW or SGD')
    parser.add_argument('--augmentation',default=False, help='choose to do random flip rotation')
    parser.add_argument('--batchsize', type=int,default=2, help='training batch size')
    parser.add_argument('--trainsize', type=int,default=704, help='training dataset size,candidate=352,704,1056')
    parser.add_argument('--print_interval', type=int, default=50, help='每隔多少batch打印一次日志')
    parser.add_argument('--clip', type=float,default=0.5, help='gradient clipping margin')
    parser.add_argument('--load', type=str, default='./Save_path/Hitnet/Net_epoch_best.pth', help='train from checkpoints')
    parser.add_argument('--decay_rate', type=float,default=0.1, help='decay rate of learning rate')
    parser.add_argument('--decay_epoch', type=int,default=50, help='every n epochs decay learning rate')
    parser.add_argument('--train_path', type=str,default='./PCOD_1200/full-dataset/train',help='path to train dataset')
    parser.add_argument('--test_path', type=str,default='./PCOD_1200/full-dataset/test',help='path to testing dataset')
    parser.add_argument('--save_path', type=str,default='./Save_path/'+model_name+'/')
    parser.add_argument('--epoch_save', type=int,default=1, help='every n epochs to save model')
    opt = parser.parse_args()


    if not os.path.exists(opt.save_path):
        os.makedirs(opt.save_path)
    log_file = os.path.join(opt.save_path, 'log', 'log.log')
    logging.basicConfig(filename=log_file,
                        format='[%(asctime)s-%(filename)s-%(levelname)s:%(message)s]',
                        level=logging.INFO, filemode='a', datefmt='%Y-%m-%d %I:%M:%S %p')
    logging.info("Network-Train")

    #epoc日志
    # 创建一个新的日志记录器
    epoc_logger = logging.getLogger('new_logger')
    epoc_logger.setLevel(logging.INFO)

    # 创建一个文件处理器，用于写入新的日志文件
    epoc_log_file = os.path.join(opt.save_path,'log','epoc_log.log')
    epoc_file_handler = logging.FileHandler(epoc_log_file)
    epoc_file_handler.setLevel(logging.INFO)

    # 创建一个日志格式器，并将其添加到文件处理器中
    epoc_formatter = logging.Formatter('[%(asctime)s-%(filename)s-%(levelname)s:%(message)s]',
                                      datefmt='%Y-%m-%d %I:%M:%S %p')
    epoc_file_handler.setFormatter(epoc_formatter)

    # 将文件处理器添加到新的日志记录器中
    epoc_logger.addHandler(epoc_file_handler)


    # ---- build models ----
    torch.cuda.set_device(0)  # set your gpu device
    model = Hitnet().cuda()

    #加载预训练模型
    if opt.load is not None:
        pretrained_dict=torch.load(opt.load)
        print('!!!!!!Sucefully load model from!!!!!! ', opt.load)
        load_matched_state_dict(model, pretrained_dict)

    # def count_parameters(model):
    #     return sum(p.numel() for p in model.parameters() if p.requires_grad)
    #打印参数量
    print('model paramters',sum(p.numel() for p in model.parameters() if p.requires_grad))

    best = 0

    params = model.parameters()
    #选择优化器
    if opt.optimizer == 'AdamW':
        optimizer = torch.optim.AdamW(params, opt.lr, weight_decay=1e-4)
    else:
        optimizer = torch.optim.SGD(params, opt.lr, weight_decay=1e-4, momentum=0.9)

    print(optimizer)
    #设置训练数据和标签的路径
    image_root = '{}/train-rgb/'.format(opt.train_path)
    gt_root = '{}/train-gt/'.format(opt.train_path)
    dolp_root = '{}/train-dop/'.format(opt.train_path)
    train_loader = get_loader(image_root,dolp_root,gt_root, batchsize=opt.batchsize, trainsize=opt.trainsize,
                              augmentation=opt.augmentation)
    total_step = len(train_loader)

    writer = SummaryWriter(opt.save_path + 'summary')
    #初始化 SummaryWriter，用于记录训练过程中的标量数据，便于在 TensorBoard 中可视化。
    print("#" * 20, "Start Training", "#" * 20)
    best_mae = 1
    best_epoch = 0
    for epoch in range(1, opt.epoch):
        adjust_lr(optimizer, opt.lr, epoch, 0.1, decay_epoch=opt.decay_epoch)  #decay——epoch，每个多少轮衰减一次学习率。
        train(train_loader, model, optimizer, epoch, opt.save_path)
        # 每隔指定轮次验证模型并保存最佳参数
        if epoch % opt.epoch_save==0:
            val( model, epoch, opt.save_path, writer)
