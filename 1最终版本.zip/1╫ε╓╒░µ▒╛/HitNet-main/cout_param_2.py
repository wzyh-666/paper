import torch
import torch.nn as nn
from lib.pvt import Hitnet
from thop import profile
model = Hitnet()
input1 = torch.randn(1,3, 384, 384)
input2 = torch.randn(1,3, 384, 384)
flops, params = profile(model, inputs=(input1,input2 ))
print('FLOPs = ' + str(flops/1000**3) + 'G')
print('Params = ' + str(params/1000**2) + 'M')